export const endPoints = {
    // apiUrl: 'http://localhost:3000/api',
    apiUrl: 'https://id90.herokuapp.com/api',
    // apiUrl: 'http://private-b56c7-id90.apiary-mock.com',
    cards: '/cards',
    allTasksInCard: '/cards/all'
}